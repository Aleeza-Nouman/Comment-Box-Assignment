import CommentSection from "./pages/commentsection";


function App() {
  return (
    <>
    <CommentSection/>
    </>
  );
}

export default App;

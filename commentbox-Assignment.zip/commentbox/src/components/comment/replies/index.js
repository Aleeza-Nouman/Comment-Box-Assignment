import React from 'react';
import './styles.css';

const Reply = ({ comment, reply, onDeleteReply, onLikeReply }) => {
  const handleLike = () => {
    onLikeReply(reply.id);
  };
  return (
    <div className="reply">
      <img src={reply.imageUrl} alt="User" />
      <div>
        <div>
          <strong>{reply.userName}</strong>
          <p>{reply.replyText}</p>
        </div>
        <div className='text-red'>
          <span onClick={handleLike}>
            {reply.likes}
            {reply.liked ? <span>&#x2665;</span> : <span>&#x2661;</span>}
          </span>
          <span style={{color:"red"}} onClick={() => onDeleteReply(comment.id, reply.id)}>
            Remove
          </span>
        </div>
      </div>
    </div>
  );
};

export default Reply;

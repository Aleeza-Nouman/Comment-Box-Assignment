import React, { useState } from 'react';
import Reply from './replies';
import AddReplyForm from './addReply';

import './styles.css';

const Comment = ({
  comment,
  onAddReply,
  onDeleteComment,
  onLikeComment,
  onLikeReply,
  onDeleteReply,
}) => {
  const [showReplies, setShowReplies] = useState(false);
  const [liked, setLiked] = useState(false);

  const handleToggleReplies = () => {
    setShowReplies(!showReplies);
  };

  const handleLike = () => {
    if (!liked) {
      onLikeComment(comment.id, true);
    } else {
      onLikeComment(comment.id, false);
    }
    setLiked(!liked);
  };
  const handleLikeReply = (replyId) => {
    onLikeReply(comment.id, replyId);
  };

  return (
    <>
      <div className="flex flex-col border-2 border-['#ccc'] ">
        <div className="comment ">
        <img src={comment.imageUrl} alt="User" />
        <div>
          <div>
            <strong>{comment.userName}</strong>
            <p>{comment.commentText}</p>
          </div>
          <div>
            <span onClick={handleLike}>
              {liked ? (
                <span style={{ color: 'red' }}>&#x2665;</span>
              ) : (
                <span style={{ color: 'black' }}>&#x2661;</span>
              )}
            </span>
            <span>{comment.likes}</span>
            <span style={{ color: 'blue' }} onClick={handleToggleReplies}>
              Reply
            </span>
            <span style={{ color: 'red' }} onClick={() => onDeleteComment(comment.id)}>Remove</span>
          </div>
        </div>
            </div>
        <div>
        {showReplies && (
          <div className="replies flex flex-col">
            {comment.replies.map((reply) => (
              <div className="pl-7">
                <Reply
                  key={reply.id}
                  comment={comment}
                  reply={reply}
                  onLikeReply={handleLikeReply}
                  onDeleteReply={onDeleteReply}
                />
              </div>
            ))}
            <AddReplyForm onAddReply={onAddReply} parentId={comment.id} />
          </div>
        )}
        </div>
      </div>
    </>
  );
};

export default Comment;

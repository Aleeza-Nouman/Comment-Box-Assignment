import React, { useState } from 'react';
import './styles.css';

const AddReplyForm = ({ onAddReply, parentId }) => {
  const [replyText, setReplyText] = useState('');

  const handleAddReply = () => {
    if (replyText.trim() !== '') {
      onAddReply(
        {
          id: Math.floor(Math.random() * 1000),
          userName: 'Jane Doe',
          replyText,
          imageUrl:
            'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',

          likes: 0,
        },
        parentId,
      );
      setReplyText('');
    }
  };

  return (
    <div className="add-reply pl-2 flex flex-row justify-between align-middle items-center pr-3">
      <input
        type="text"
        value={replyText}
        onChange={(e) => setReplyText(e.target.value)}
        placeholder="Write your comment"
      />
   
      
      <div>
        <svg
            width="16"
            height="18"
            viewBox="0 0 16 18"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            onClick={handleAddReply}
            className="h-6 w-6 cursor-pointer text-blue-500 "
          >
            <g clip-path="url(#clip0_26_336)">
              <path
                d="M14.8763 1.09851L0.390353 9.45565C-0.175333 9.78069 -0.10345 10.5683 0.45911 10.8058L3.78134 12.1997L12.7604 4.28635C12.9323 4.13321 13.1761 4.36761 13.0292 4.54575L5.50028 13.7186L5.50028 16.2345C5.50028 16.9721 6.391 17.2627 6.82854 16.7283L8.81313 14.3124L12.7073 15.9438C13.1511 16.1314 13.6574 15.8532 13.7387 15.375L15.9889 1.87359C16.0952 1.24227 15.417 0.785973 14.8763 1.09851Z"
                fill="#6590FF"
              />
            </g>
            <defs>
              <clipPath id="clip0_26_336">
                <rect
                  width="16"
                  height="16.0049"
                  fill="white"
                  transform="translate(0 0.997536)"
                />
              </clipPath>
            </defs>
          </svg>
      </div>
      
     
    </div>
  );
};

export default AddReplyForm;

import React, { useState } from 'react';
import { data } from '../../constants/data';
import Comment from '../../components/comment';
import AddComment from 'components/comment/AddComment';

import './styles.css';
const CommentSection = () => {
  const [comments, setComments] = useState(data);

  const handleAddReply = (newReply, commentId) => {
    setComments((prevComments) => {
      return prevComments.map((comment) => {
        if (comment.id === commentId) {
          return { ...comment, replies: [...comment.replies, newReply] };
        }
        return comment;
      });
    });
  };

  const handleDeleteComment = (commentId) => {
    setComments(comments.filter((comment) => comment.id !== commentId));
  };

  const handleDeleteReply = (commentId, replyId) => {
    const updatedComments = comments.map((comment) => {
      if (comment.id === commentId) {
        return {
          ...comment,
          replies: comment.replies.filter((reply) => reply.id !== replyId),
        };
      }
      return comment;
    });

    setComments(updatedComments);
  };
  const handleLikeReply = (commentId, replyId) => {
    setComments((prevComments) => {
      return prevComments.map((comment) => {
        if (comment.id === commentId) {
          return {
            ...comment,
            replies: comment.replies.map((reply) => {
              if (reply.id === replyId) {
                const newLikes = reply.liked
                  ? Math.max(reply.likes - 1, 0)
                  : reply.likes + 1;
                return {
                  ...reply,
                  likes: newLikes,
                  liked: !reply.liked,
                };
              }
              return reply;
            }),
          };
        }
        return comment;
      });
    });
  };

  const handleLikeComment = (commentId) => {
    setComments((prevComments) => {
      return prevComments.map((comment) => {
        if (comment.id === commentId) {
          return {
            ...comment,
            likes: comment.liked
              ? comment.likes - 1
              : comment.likes
              ? comment.likes + 1
              : 1,
            liked: !comment.liked,
          };
        }
        return comment;
      });
    });
  };

  return (
    <div className="comment-section">
      <h2 className="font-bold">Comments</h2>
      {comments.map((comment) => (
        <div className="pb-2">
          <Comment
            key={comment.id}
            comment={comment}
            onAddReply={handleAddReply}
            onDeleteComment={handleDeleteComment}
            onDeleteReply={handleDeleteReply}
            onLikeComment={handleLikeComment}
            onLikeReply={handleLikeReply}
          />
        </div>
      ))}

      <AddComment comments={comments} setComments={setComments} />
    </div>
  );
};

export default CommentSection;
